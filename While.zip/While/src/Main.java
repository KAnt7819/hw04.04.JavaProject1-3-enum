import java.util.Random;

public class Main {

    //1 уровень сложности: Проект 1. Используйте while:
    //Напиши программу, которая моделирует ситуацию.
    //Ты попросил друзей скинуться на подарок на твой День Рождения. Каждый друг случайным образом может подарить тебе одну купюру номиналом 500,
    // 1000, 2000 или 5000 рублей. Твоя цель - новенький игровой ПК, который стоит 100 000 рублей.
    //Как только друзья подарят тебе нужную сумму (или даже чуть больше), останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
    //
    //Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Пользователь указывает нижнюю и верхнюю границу диапазона.
    //
    //
    //Проект 3.
    //Используйте foreach.
    //Дан Enum месяцев. Пользователь вводит имя текущего месяца в консоль. Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
    public static void main(String[] args) {

//        final int PC_PRICE = 100000;
////        final int[] BILL_VALUES = {500, 1000, 2000, 5000};
////
////        Random random = new Random();
////        int giftSum = 0;
////        int numGifts = 0;
////
////        while (giftSum < PC_PRICE) {
////            int gift = BILL_VALUES[random.nextInt(BILL_VALUES.length)];
////            giftSum += gift;
////            numGifts++;
////            System.out.println("Received gift of " + gift + " rubles. Total received: " + giftSum + " rubles.");
////        }

        int total = 0;
        //wkljuchaet schetchik
        int finalAmount = 100000;
        //ogranichenie po maksimumu, chislo kotoroe nugno dostich
        Random rnd = new Random();
        while (total < finalAmount) {
            System.out.println("Sobrannaja summa na danni moment:" + total);
            int a = 0;
            int randomNumber = rnd.nextInt(4);
            switch (randomNumber) {
                case 0:
                    a = 500;
                    break;
                case 1:
                    a = 1000;
                    break;
                case 2:
                    a = 2000;
                    break;
                case 3:
                    a = 5000;
                    break;
            }
            total += a;
        }
        System.out.println("Sobrannaja summa na danni moment:" + total);
        System.out.println("drusja, summa uge rawna " + total + " rublei");


    }
}