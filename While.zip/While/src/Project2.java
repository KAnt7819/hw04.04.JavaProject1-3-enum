import java.util.Random;
import java.util.Scanner;

public class Project2 {


    //Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Пользователь указывает нижнюю и верхнюю границу диапазона.

    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Введите два любых числа: ");
        int a = scr.nextInt();
        int b = scr.nextInt();
        int sum = 0;

        for (int i = a; i <= b; i++) {
            if (i % 2 == 1) { // проверка на нечетность
                sum += i; //увеличивает значение на 1 (инкремент)
            }
        }
        System.out.println("Сумма нечетних чисел в диапазоне от: " + a + " до " + b + " равна " + sum);
    }
}